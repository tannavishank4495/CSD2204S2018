module BlazeDemoTest 
{public class BlazeDemoTest {

	

	WebDriver driver;



	@Before

	public void setUp() throws Exception {

		System.setProperty("webdriver.chrome.driver", "/Users/jasvirkaur/Desktop/chromedriver");

		WebDriver driver =  new ChromeDriver();

		

		driver.get("https://blazedemo.com" );



	}



	@After

	public void tearDown() throws Exception {

		Thread.sleep(5000);

	//	driver.close();

		}



	@Test

	public void testCase1() {

		List<WebElement> departureCitites = driver.findElements(

				By.);

		System.out.println("Number of cities: " + departureCitites.size());



		

		

	}



}
}