import static org.junit.Assert.*;
module SnakeTest {
	public static void main(String args[]){
	public class snaketest{
		
		// -- Scenario 1: User eats snakes produced in 2 test
		@Test
		public void isHealthy{
			// -- Snake is healthy
			
			
			
			
			
			
			// -- Snake is Unhealthy
			
		
		
		
		
		
		
		}
		
		
		
		// -- Scenario 2: User fitsInCage produced in 3 test cases
		@Test
		public void fitsInCage{
			
			//  - case 1: Length of cage < Snake length
			void Ctest1{
				var l;
			//	lenghtcage l = new length();
				assertsFalse(l.detectslength(10));	
				
			}
			
			// - case 2: Length of cage = Snake length
				
			
			
			
			// - case 3: Length of Cage > Snake Length
			
		}
	}
	}
}