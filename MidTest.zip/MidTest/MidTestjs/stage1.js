var savBal = 1000;
var chBal = 1000;
var check;

function balTrans()
{
if(document.getElementById("mySelect1").value == 1 || document.getElementById("mySelect1").value == 2)
{
  var Bal = parseInt(document.getElementById("currBal").value);
  if(document.getElementById("traBal").value == document.getElementById("traBal").defaultValue)
  {
    alert("Please Enter value");
    return;
  }

  var tb = parseInt(document.getElementById("traBal").value);

  if(Bal<tb)
  {
//		console.log("hi");
    alert("Insufficient Balance. Enter amount less than Current Balance");
  }
  else if(tb == 0)
  {
    alert("Transfer balance can't be 0")
  }
  else if(tb < 0)
  {
    alert("Transfer balance can't be negative")
  }
  else
  {

    Bal = Bal - tb;

    document.getElementById("currBal").value = Bal;

    document.getElementById("finBal").value = Bal;

    if(document.getElementById("mySelect1").value == 1)
    {
      chBal = Bal;
      savBal = savBal + tb;
    }
    else if(document.getElementById("mySelect1").value == 2)
    {
      savBal = Bal;
      chBal = chBal + tb;
    }

  }

  document.getElementById("traBal").type="text";

  document.getElementById("traBal").value = document.getElementById("traBal").defaultValue;
}
else
{
  alert("Please select From and To account");
}
return;
};

function enableNext()
{
// start 1 -- logic for displaying checking and savings accoubt balance ---
//	console.log(document.getElementById("mySelect1").value);
if(document.getElementById("mySelect1").value == 1)
{
  document.getElementById("currBal").value = chBal;
}
else if(document.getElementById("mySelect1").value == 2)
{
  document.getElementById("currBal").value = savBal;
}
else
{
  document.getElementById("currBal").value = document.getElementById("currBal").defaultvalue;
}
// end 1 --
// start 2 -- 2nd dropdown menu enable disable logic
document.getElementById("mySelect2").disabled = false;
document.getElementById("mySelect2").options[document.getElementById("mySelect1").value].selected = false;
for(i=1;i<3;i++)
{
  document.getElementById("mySelect2").options[i].disabled = false;
}
document.getElementById("mySelect2").options[document.getElementById("mySelect1").value].disabled = true;
// end 2 ---
}

function clearDefault(a)
{
if(a.defaultValue == a.value)
{
  a.value="";
}
a.type ="Number";
}

function getUserName()
{
var url = window.location.search;

document.getElementById('un').innerHTML = url.substring(10);


}
