function myFunction() {
    var x, text, y;

    // Get the value of the input field with id="numb" and id="text"
    x = document.getElementById("numb").value;
    y = document.getElementById("text").value;

    // If x and y value matches as stated
    if (x == "123" && y == "abc" ) {
        text = "Login Successful";
        //window.open("MidTest2.html");
        window.location.href = "MidTest2.html?username="+document.getElementById("numb").value;
    } else {
        text = "Check your ID or Password fields ";
    }
    document.getElementById("demo").innerHTML = text;
}
